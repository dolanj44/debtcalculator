﻿var app = angular.module("evolve", ["ngRoute", "ui.bootstrap"]);
app.config(function ($compileProvider, $routeProvider) {

    //because angular adds unsafe before some urls like sip so adding them to whitelist
    $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|sip|chrome-extension):/);
    //$compileProvider.aHrefSanitizationWhitelist(/^\s*(sip|tel|mailto|goto):/);
    $routeProvider
    .when("/", {
        templateUrl: "main.html",
        controller: "eventsCtrl"
    })
    .when("/brightspot", {
        templateUrl: "brightspot.html",
        controller: "brightSpotCtrl"
    })
    .when("/events", {
        templateUrl: "events.html",
        controller: "eventsCtrl"
    })
    .when("/team", {
        templateUrl: "team.html",
        controller: "teamCtrl"
    })
    .when("/faq", {
        templateUrl: "faq.html",
        controller: "faqCtrl"
    })
    .when("/TFS", {
        templateUrl: "TFS.html",
        controller:"tfsCtrl"
    })
    .when("/tools", {
        templateUrl: "tools.html",
        controller: "toolsCtrl"
    })

    .when("/selfhelp", {
        templateUrl: "selfhelp.html",
        controller: "selfHelpCtrl"
    })
    ;
});

app.controller('eventsCtrl', function ($scope, $http, dateConvertor, displayPictureConvertor) {
    $http.get('https://ishareteam2.na.xom.com/sites/EvolveWrk/_vti_bin/ListData.svc/EventList').
        then(function (res) {

            //shifting the response from rest call(res) into local variable(response)
            var response = res;
            var i = 0;
            while (i < response.data.d.results.length) {
              //using the dateConvertor service to convert the json date to the format required in the view
                response.data.d.results[i].Month = dateConvertor.getUsableMonth(response.data.d.results[i].DateAndTime);
                response.data.d.results[i].Day = dateConvertor.getUsableDay(response.data.d.results[i].DateAndTime);
                response.data.d.results[i].Year = dateConvertor.getUsableYear(response.data.d.results[i].DateAndTime);

                //getting the date of event and current date to filter out past events in the view
                response.data.d.results[i].Date = (new Date(dateConvertor.getUsableDate(response.data.d.results[i].DateAndTime))).toISOString().slice(0, 10).replace(/-/g, "");
                response.data.d.results[i].CurrentDate = (new Date()).toISOString().slice(0, 10).replace(/-/g, "");

                //display picture in sharepoint appends alternate text to the end of image path so removing that to get only the image path
                response.data.d.results[i].EventxRegistrationLink = displayPictureConvertor.displayPictureConversionFunction(response.data.d.results[i].EventxRegistrationLink);


                //classifying type of icon to be used based on the training type
                if (response.data.d.results[i].TrainingTypeValue == "training") {
                    response.data.d.results[i].image = "images/event-training2.png";
                }
                if (response.data.d.results[i].TrainingTypeValue == "speaker") {
                    response.data.d.results[i].image = "images/event-speaker2.png";
                }
                if (response.data.d.results[i].TrainingTypeValue == "conference") {
                    response.data.d.results[i].image = "images/event-conference2.png";
                }


                i++;
            }

            //creating eventList scope to push the modified response data to the view
            $scope.eventList = response.data.d.results;
            //console.log(response.data.d.results);
        });
});
app.controller('brightSpotCtrl', function ($scope, $http, dateConvertor) {
    $http.get('https://ishareteam2.na.xom.com/sites/ASC/ASC_WEB/articles/_vti_bin/ListData.svc/Posts').
        then(function (res) {

            //shifting the response from rest call(res) into local variable(response)
            //console.log(res);
            var response = res;
            var i = 0;
            while (i < response.data.d.results.length) {
                //response.data.d.results[i].Author = getAuthor(i);
                /*
                if (authorData[i].Name) {
                    response.data.d.results[i].Author = authorData[i].Name;
                }
                 */
                 //console.log(response.data.d.results);
                if (response.data.d.results[i].CreatedById == 251) {
                    response.data.d.results[i].Author = "Brian Rait";
                }
                if (response.data.d.results[i].CreatedById == 196) {
                    response.data.d.results[i].Author = "Tanes Jedsadawaranon";
                }
                response.data.d.results[i].Month = dateConvertor.getUsableMonth(response.data.d.results[i].Created);
                response.data.d.results[i].Day = dateConvertor.getUsableDay(response.data.d.results[i].Created);
                response.data.d.results[i].Year = dateConvertor.getUsableYear(response.data.d.results[i].Created);
                i++;
            }

            //console.log(response.data.d.results);
            //creating post scope to push the modified response data to the view
            $scope.post = response.data.d.results;
        });


        });
app.controller('toolsCtrl', function ($scope, $http) {

  $http.get('https://ishareteam2.na.xom.com/sites/EvolveWrk/_vti_bin/ListData.svc/ToolsList').
  then(function (res) {
      //shifting the response from rest call(res) into local variable(response)
      //console.log(res);
      var response = res;
      $scope.toolsData = response.data.d.results;
  });
  //this SP list contains all the header info for teh dropdowns
  $http.get('https://ishareteam2.na.xom.com/sites/EvolveWrk/_vti_bin/ListData.svc/ToolsListHeader').
  then(function (res) {
      //shifting the response from rest call(res) into local variable(response)
      //console.log(res);
      var response = res;
      //limit variables to calculate the non null values in those categories
      $scope.categoryLimit = 0;
      $scope.SDOLimit = 0;
      $scope.selfserviceLimit = 0;
        var i = 0;
        while (i < response.data.d.results.length) {
          if(response.data.d.results[i].Categories != null){
            $scope.categoryLimit++;
            }
          if(response.data.d.results[i].SDO != null){
            $scope.SDOLimit++;
            }
          if(response.data.d.results[i].SelfService != null){
            $scope.selfserviceLimit++;
            }
          i++;
        }
      $scope.toolsDataHeader = response.data.d.results;
  });


});
app.controller('teamCtrl', function ($scope, $http, $q, displayPictureConvertor, $location, $anchorScroll) {
  // $scope.scrollTo = function(id) {
  //     $location.hash(id);
  //     console.log($location.hash());
  //     $anchorScroll();
  //   };
    $http.get('https://ishareteam2.na.xom.com/sites/EvolveWrk/_vti_bin/ListData.svc/TeamList').
            then(function (res) {
                //shifting the response from rest call(res) into local variable(response)
                var response = res;

                var i = 0;
                $scope.ticketAPIData = [];

                while (i < response.data.d.results.length) {

                    response.data.d.results[i].DomainLanID = (response.data.d.results[i].Domain + '\\' + response.data.d.results[i].LanID).toLowerCase();

                    //SP list returns the image URL with caption in the same string so removing
                    //everything after the http://../../abc.jpg using the displayPictureConvertor service
                    response.data.d.results[i].Display_picture = displayPictureConvertor.displayPictureConversionFunction(response.data.d.results[i].Display_picture);

                    //counter variable to check how many ticket api calls are made
                    var counter = 0;
                      $http.get('https://ticket/api/user/' + response.data.d.results[i].Domain + '_' + response.data.d.results[i].LanID, { withCredentials: true }).
                      then(function (successResponse) {
                          counter++;
                           $scope.ticketAPIData.push(successResponse);

                           //after the last ticket api call, we loop through the $scope.ticketAPIData and match the domain name and LanID
                           //to orignal SP list response and map the two data sets
                           if(counter == response.data.d.results.length){
                             var j = 0, k = 0;
                             while(k < response.data.d.results.length){
                               j = 0;
                               while(j < response.data.d.results.length){

                                     if(response.data.d.results[k].DomainLanID == $scope.ticketAPIData[j].data.Login_ID){
                                       response.data.d.results[k].full_name = $scope.ticketAPIData[j].data.Full_Name;
                                       response.data.d.results[k].email = $scope.ticketAPIData[j].data.Email_Address;
                                       response.data.d.results[k].phone = $scope.ticketAPIData[j].data.Business_Phone;
                                     }
                                   j++;
                                 }
                              k++;
                              }
                             $scope.evolveTeam = response.data.d.results;

                           }
                      }, function (failedResponse) { });

                    i++;


                  }
                  });
    });

  /*
  if(response.data.d.results[j].DomainLanID == $scope.ticketAPIData[j].data.Login_ID){
    console.log($scope.ticketAPIData[j].data.Login_ID);
  }
  */
app.controller('selfHelpCtrl', function ($scope, $http, $location, $anchorScroll) {
  $anchorScroll.yOffset = 150;
    $scope.scrollTo = function(id) {
      var old = $location.hash();
      $location.hash(id);
      $anchorScroll();
      //reset to old to keep any additional routing logic from kicking in
      $location.hash(old);
    };
  $http.get('js/selfHelpData.txt').
          then(function (res) {
            //console.log(res);
          //shifting the response from rest call(res) into local variable(response)
          var response = res;
          //console.table(response.data.d.results);
          $scope.selfHelpData = response.data;
          //console.log(selfHelpData);
        });

});
app.controller('faqCtrl', function ($scope, $http, $q) {
    var deferred = $q.defer();
    var baseURL = 'https://ishareteam2.na.xom.com/sites/EvolveWrk/_vti_bin/ListData.svc/';
    var listURL = 'FaqList';
    $http.get(baseURL + listURL, { withCredentials: true }).then(
        function (successResponse) {
            //console.table(successResponse.data.d.results);
            $scope.faqData = successResponse.data.d.results;
        }, function (failedResponse) {
            console.log(failedResponse);
        });
    return deferred.promise;

});
app.controller('tfsCtrl',function($scope, $location, $anchorScroll) {
  $anchorScroll.yOffset = 150;
    $scope.scrollTo = function(id) {
      var old = $location.hash();
      $location.hash(id);
      $anchorScroll();
      //reset to old to keep any additional routing logic from kicking in
      $location.hash(old);
    };
});
app.controller('myModalController', function ($rootScope, $scope, $filter, $modal, $http) {
    $scope.requestForm = [];
    $scope.checkItem = "";
    $scope.loadEditForm = function () {
        $scope.checkItem = "yes";
        $modal.open({
            templateUrl: 'modal.html',
            controller: 'modalController',
            scope: $scope
        })
        .result.then(function() {
            alert('Your request is submitted !');
        }, function() {
            //alert('canceled');
        });
    };

    $scope.getFormData = function() {
        //var data = JSON.parse($scope.requestForm);
        //console.log($scope.requestForm);

        var requestConsultation =  "https://ishareteam2.na.xom.com/sites/ASC/ASC_WEB/_vti_bin/ListData.svc/RequestConsultation";

        var dataObj = {
            "RequestTypeValue": $scope.requestForm.request,
            "RegionValue": $scope.requestForm.region,
            "Team": $scope.requestForm.team,
            "RequestDetail":$scope.requestForm.details,
            "StatusValue": "New"
        };

        $http({
            method: 'POST',
            headers: { "Accept": "application/json" },
            processData: false,
            url: requestConsultation,
            data: JSON.stringify(dataObj),
            dataType: "json"
            }).success(function (data) {
                //console.log("POST worked" + data);
            }).error(function (er) {
                //console.log('Error = ' + er);
            });
    };

});
app.controller('modalController',function($scope) {});
app.filter("trust", function ($sce) {
    return function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    }
});
// app.directive('showNavActive', function () {
//     return {
//         link: function ($scope, element, attrs) {
//
//
//
//             element.bind('click', function (e) {
//
//                 var link = $(e.currentTarget.id);
//                 //console.log(link);
//                 //console.log($(e.id));
//                 //console.log(element[0].id);
//
//                 //getting id of the clicked element
//                 var navID = element[0].id;
//
//                 //removing unnecessary crap in front of the id to get the id digits
//                 navID = navID.substring(navID.indexOf("-") + 1);
//                 //console.log(navID);
//
//                 //remove active class from all other navigation list items
//                 angular.element('.nav-li').removeClass('active');
//
//                 //add active class to the clicekd element
//                 angular.element(element).addClass('active');
//
//                 //adding class with display:none to every element in the section
//                 angular.element('.displayDiv').addClass('inactiveDiv');
//
//                 //removing the display:none so that only the elemenet correcsponding to the clicked nav item is shown
//                 angular.element('#content'+navID).removeClass('inactiveDiv');
//             });
//         }
//     }
// });
// app.directive('myYoutube', function($sce) {
//   return {
//     restrict: 'EA',
//     scope: { code:'=' },
//     replace: true,
//     template: '<div style="height:400px;"><iframe style="overflow:hidden;height:100%;width:100%" width="100%" height="100%" src="{{url}}" frameborder="0" allowfullscreen></iframe></div>',
//     link: function (scope) {
//         console.log('here');
//         scope.$watch('code', function (newVal) {
//            if (newVal) {
//                scope.url = $sce.trustAsResourceUrl("http://www.youtube.com/embed/" + newVal);
//            }
//         });
//     }
//   };
// });
app.service('dateConvertor', function() {
    this.getUsableDate = function (MyDate) {
        var value = new Date
                          (
                               parseInt(MyDate.toString().replace(/(^.*\()|([+-].*$)/g, ''))
                          );
        var result = value.getMonth() +
                                 1 +
                               "/" +
                   value.getDate() +
                               "/" +
               value.getFullYear();
        return result;
    }
    this.getUsableMonth = function (MyDate) {
        var value = new Date
                          (
                               parseInt(MyDate.toString().replace(/(^.*\()|([+-].*$)/g, ''))
                          );
        return this.monthOfEvent(value.getMonth() + 1);
    }
    this.getUsableDay = function (MyDate) {
        var value = new Date
                          (
                               parseInt(MyDate.toString().replace(/(^.*\()|([+-].*$)/g, ''))
                          );
        return value.getDate();
    }
    this.getUsableYear = function (MyDate) {
        var value = new Date
                          (
                               parseInt(MyDate.toString().replace(/(^.*\()|([+-].*$)/g, ''))
                          );
        return value.getFullYear();
    }
    this.monthOfEvent = function (dateVar) {
        var month;
        switch (dateVar) {
            case 1:
                month = "JAN";
                break;
            case 2:
                month = "FEB";
                break;
            case 3:
                month = "MAR";
                break;
            case 4:
                month = "APR";
                break;
            case 5:
                month = "MAY";
                break;
            case 6:
                month = "JUN";
                break;
            case 7:
                month = "JUL";
                break;
            case 8:
                month = "AUG";
                break;
            case 9:
                month = "SEP";
                break;
            case 10:
                month = "OCT";
                break;
            case 11:
                month = "NOV";
                break;
            case 12:
                month = "DEC";
                break;

        }
        return month;
    }
});
app.service('displayPictureConvertor', function() {
    this.displayPictureConversionFunction = function (displayPicturePath) {

      var s = displayPicturePath.toString();
      var n = s.indexOf(',');
      s = s.substring(0, n != -1 ? n : s.length);
      return s;
    }
});
// app.service('anchorSmoothScroll', function(){
//
//     this.scrollTo = function(eID) {
//
//         // This scrolling function
//         // is from http://www.itnewb.com/tutorial/Creating-the-Smooth-Scroll-Effect-with-JavaScript
//
//         var startY = currentYPosition();
//         var stopY = elmYPosition(eID);
//         var distance = stopY > startY ? stopY - startY : startY - stopY;
//         if (distance < 100) {
//             scrollTo(0, stopY); return;
//         }
//         var speed = Math.round(distance / 100);
//         if (speed >= 20) speed = 20;
//         var step = Math.round(distance / 25);
//         var leapY = stopY > startY ? startY + step : startY - step;
//         var timer = 0;
//         if (stopY > startY) {
//             for ( var i=startY; i<stopY; i+=step ) {
//                 setTimeout("window.scrollTo(0, "+leapY+")", timer * speed);
//                 leapY += step; if (leapY > stopY) leapY = stopY; timer++;
//             } return;
//         }
//         for ( var i=startY; i>stopY; i-=step ) {
//             setTimeout("window.scrollTo(0, "+leapY+")", timer * speed);
//             leapY -= step; if (leapY < stopY) leapY = stopY; timer++;
//         }
//
//         function currentYPosition() {
//             // Firefox, Chrome, Opera, Safari
//             if (self.pageYOffset) return self.pageYOffset;
//             // Internet Explorer 6 - standards mode
//             if (document.documentElement && document.documentElement.scrollTop)
//                 return document.documentElement.scrollTop;
//             // Internet Explorer 6, 7 and 8
//             if (document.body.scrollTop) return document.body.scrollTop;
//             return 0;
//         }
//
//         function elmYPosition(eID) {
//             var elm = document.getElementById(eID);
//             var y = elm.offsetTop;
//             var node = elm;
//             while (node.offsetParent && node.offsetParent != document.body) {
//                 node = node.offsetParent;
//                 y += node.offsetTop;
//             } return y;
//         }
//
//     };
//
// });
