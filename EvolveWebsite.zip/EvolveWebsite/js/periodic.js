﻿$(function () {
    resize_table();
    $(window).resize(function () {
        resize_table();
    });
    function resize_table() {
        var percent = $('.wrapper').parent().width() / 1068;
        $('.wrapper').css({
            '-ms-zoom': percent,
            '-moz-transform': 'scale(' + percent + ')',
            '-moz-transform-origin': '0 0',
            '-o-transform': 'scale(' + percent + ')',
            '-o-transform-origin': '0 0',
            '-webkit-transform': 'scale(' + percent + ')',
            '-webkit-transform-origin': '0 0'
        });
        $('.wrapper').parent().css({
            'height': $('.wrapper').height() * percent
        });
    }
    $.ajax({
        url: 'https://xebialabs.com/periodic-table-of-devops-tools/elements.js',
        type: 'post',
        dataType: "json",
        success: function (data, status) {
            if (data) {
                $.each(data.elements, function (key, element) {
                    var id = element.id;
                    var selector = '#' + element.id;
                    var name = element.name;
                    var url = element.url;
                    var type = "type-" + element.type.toString().split(",", 1);
                    var model = "model-" + element.model;
                    var nb = element.nb;
                    var image = element.image;
                    var classes = type + ' ' + model + ' element';
                    var index = $('.main > li:not(.empty)').index($(selector)) + 1;
                    var nameLength = name.length;
                    $(selector).addClass(classes).attr({
                        'data-name': name,
                        'data-id': id,
                        'data-image': image,
                        'data-url': url,
                        'data-nb': nb,
                        'data-pos': index,
                        'data-model': element.model,
                        'data-type': element.type.split(',', 1),
                    });
                    $(selector).find('span').text(name);
                    if (nameLength > 13) {
                        $(selector).css({
                            "padding-top": "10px"
                        });
                    }
                });
            }
        },
        error: function (xhr, desc, err) {
            console.log(xhr);
            console.log("Details: " + desc + "\nError:" + err);
        }
    }).done(function (data) {
        var tl = new TimelineMax();
        tl.fromTo("#spinner", .4, {
            opacity: 1,
            scale: 1
        }, {
            opacity: 0,
            scale: 0
        });
        tl.fromTo(".legend", .2, {
            opacity: 0,
            y: -30
        }, {
            opacity: 1,
            y: 0
        });
        tl.staggerFromTo('.main > li:not(.empty)', .8, {
            scale: .2,
            opacity: 0,
            ease: Power0
        }, {
            scale: 1,
            opacity: 1,
            ease: Power0
        }, .012);
        tl.staggerFromTo(".list-1 > li", .2, {
            opacity: 0,
            y: -30,
            ease: Elastic.easeOut,
            force3D: false
        }, {
            opacity: 1,
            y: 0,
            ease: Back.easeOut,
            force3D: false
        }, .015);
        tl.staggerFromTo(".list-2 > li", .2, {
            opacity: 0,
            y: -30,
            ease: Elastic.easeOut,
            force3D: false
        }, {
            opacity: 1,
            y: 0,
            ease: Back.easeOut,
            force3D: false
        }, .015);
        tl.fromTo("#logo-container", 1.4, {
            opacity: 0,
            scale: .2,
            ease: Elastic.easeOut,
            force3D: false
        }, {
            opacity: 1,
            scale: 1,
            ease: Elastic.easeOut,
            force3D: false
        });
        $('li[class^="type-"]').mouseover(function () {
            var currentClass = $(this).attr('class').split(' ')[0];
            if (currentClass != 'empty') {
                $('.main > li').addClass('deactivate');
                $('.' + currentClass).removeClass('deactivate');
            }
        });
        $('li[class^="model-"]').mouseover(function () {
            var currentClass = $(this).attr('class').split(' ')[0];
            $('.main > li').addClass('deactivate');
            $('.' + currentClass).removeClass('deactivate');
        });
        $('.main > li').mouseout(function () {
            var currentClass = $(this).attr('class').split(' ')[0];
            $('.main > li').removeClass('deactivate');
        });
        $('.type-xebialabs').mouseover(function () {
            $('.main > li').addClass('deactivate');
            $('#6547, #6549, #6550').removeClass('deactivate');
        });
        twttr.ready(function (twttr) {
            twttr.events.bind('follow', function (event) {
                var followedScreenName = event.target.attributes[8].nodeValue;
                ga('send', 'event', 'periodic table', 'element follow', followedScreenName, 1);
            });
        });
    });
    $('.main > li:not(.empty)').hover(function () {
        var tl = new TimelineMax();
        tl.to(this, .1, {
            scale: 1.8,
            ease: Back.easeOut,
            force3D: false
        });
    }, function () {
        var tl = new TimelineMax();
        tl.to(this, .1, {
            scale: 1,
            ease: Back.easeOut,
            force3D: false
        });
    });
    $(document).on("click", '.main > li:not(.empty), #element-related > li > a.related-element', function (e) {
        e.preventDefault();
        $('.main').fadeOut();
        var tl = new TimelineMax();
        tl.fromTo("#spinner", .4, {
            opacity: 0,
            scale: 0
        }, {
            opacity: 1,
            scale: 1
        });
        var tool_name = $(this).data('name');
        ga('send', 'event', 'periodic table', 'element view', tool_name, 1);
        ga('send', 'pageview', {
            'title': tool_name
        });
        $('#element-related').html('').css({
            'opacity': 0
        });
        var type_link = $('#' + $(this).data('type')).attr('href');
        var model_link = $('#' + $(this).data('model')).attr('href');
        var type_name = $('#' + $(this).data('type')).text();
        var model_name = $('#' + $(this).data('model')).find('.model-name').text();
        $.ajax({
            url: 'https://xebialabs.com/api/resources.js',
            type: 'post',
            dataType: 'json',
            data: {
                'id': $(this).data('id')
            },
            success: function (data, status) {
                if (data) {
                    $('#element').fadeIn();
                    $('#periodic-table').fadeOut();
                    $('#element-title span').text(data[0].pagetitle);
                    $('#element-logo-link').attr('href', 'https://xebialabs.com/' + data[0].uri).attr('title', data[0].pagetitle);
                    $('#element-logo').attr('src', 'https://xebialabs.com' + data[0].tvs.featured_image);
                    $('#element-content').text(data[0].introtext);
                    $('#element-model').attr('href', model_link).html('All ' + model_name + ' tools');
                    $('#element-category').attr('href', type_link).html('All ' + type_name + ' tools');
                    $('#element-website').attr('href', data[0].tvs.link);
                    $('#element-wikipedia').attr('href', data[0].tvs.wikipedia);
                    $('#element-diagram').html('<i class="fa fa-sitemap"></i>  View ' + data[0].pagetitle + ' in Diagram').attr('href', 'https://xebialabs.com/devops-diagram-generator/?tooling%5B%5D=' + data[0].id);


                    if (data[0].tvs.person_twitter_handle) {
                        $('#element-twitter-wrapper').html('<div id="twitter-button"></div>').show();
                        twttr.widgets.createFollowButton(data[0].tvs.person_twitter_handle, document.getElementById('twitter-button'), {
                            size: 'small',
                            count: 'none',
                        }).then(function (el) { });
                    } else {
                        $('#element-twitter-wrapper').hide().html('<div id="twitter-button"></div>');
                    }
                    if (data[0].tvs.taxRelated) {
                        get_related(data[0].tvs.taxRelated);
                    } else {
                        generate_related(data[0].id);
                    }
                    if (data[0].tvs.taxPlugin) {
                        $('#element-plugins').show().html('<i class="fa fa-plug"></i> View our ' + data[0].pagetitle + ' plugin!').attr('href', 'https://xebialabs.com/api/redirect/?id=' + data[0].tvs.taxPlugin.toString().split(',', 1));
                    } else {
                        $('#element-plugins').hide();
                    }
                }
            },
            error: function (xhr, desc, err) {
                console.log(xhr);
                console.log("Details: " + desc + "\nError:" + err);
            }
        });
    });
    function generate_related(id) {
        $.ajax({
            url: 'https://xebialabs.com/api/related.js',
            type: 'post',
            dataType: 'json',
            data: {
                'id': id,
                'parents': 5320,
                'limit': 6,
                'fields': 'introtext:2,tv.taxPluginType:15'
            },
            success: function (data, status) {
                if (data) {
                    get_related(data[0].related);
                }
            },
            error: function (xhr, desc, err) {
                console.log(xhr);
                console.log("Details: " + desc + "\nError:" + err);
            }
        });
    }

    function get_related(related) {
        $.ajax({
            url: 'https://xebialabs.com/api/resources.js',
            type: 'post',
            dataType: 'json',
            data: {
                'id': related,
                'fields': 'tv.taxPluginType:15,tv.taxCompany:5,introtext:1',
                'parent': 5320
            },
            success: function (data, status) {
                if (data[0]) {
                    $('#element-related').html('').css({
                        'opacity': 0
                    });
                    $.each(data, function (key, resource) {
                        $('#element-related').append('<li><a href="https://xebialabs.com/' + resource.uri + '" target="_blank" class="related-element" data-id="' + resource.id + '" data-name="' + resource.pagetitle + '" data-type="' + resource.tvs.taxPluginType.toString().split(",", 1) + '" data-model="' + resource.tvs.taxModel + '"><img src="' + resource.tvs.featured_image + '" class="related-element img-circle img-thumbnail img-responsive" /></a></li>');
                    });
                    var tl = new TimelineMax();
                    tl.to("#element-related", .1, {
                        opacity: 1
                    }).staggerFromTo('#element-related li', .4, {
                        scale: .2,
                        opacity: 0,
                        ease: Back.easeOut,
                        force3D: false
                    }, {
                        scale: 1,
                        opacity: 1,
                        ease: Back.easeOut,
                        force3D: false
                    }, .15);
                }
            },
            error: function (xhr, desc, err) {
                console.log(xhr);
                console.log("Details: " + desc + "\nError:" + err);
            }
        }).done(function () {
            var tl = new TimelineMax();
            tl.fromTo("#spinner", .4, {
                opacity: 1,
                scale: 1
            }, {
                opacity: 0,
                scale: 0
            });
            var tl = new TimelineMax();
            tl.to("#element-related", .1, {
                opacity: 1
            }).staggerFromTo('#element-related li', .4, {
                scale: .2,
                opacity: 0,
                ease: Back.easeOut,
                force3D: false
            }, {
                scale: 1,
                opacity: 1,
                ease: Back.easeOut,
                force3D: false
            }, .15);
            $('.related-element').click(function () {
                ga('send', 'event', 'periodic table', 'element view related', $(this).data('name'), 1);
            });
        });
    }
    $('#floating-actions').scrollToFixed({
        limit: function () {
            var limit = $('#footer').offset().top - $('#floating-actions').outerHeight(true) - 10;
            return limit;
        },
        removeOffsets: true,
        marginTop: 40,
        zIndex: 2,
        minWidth: 992,
    });
    $('.sidebar-cta').click(function (e) {
        e.preventDefault();
        $(window).scrollTo($('#main-content'), 200);
        $($(this).data('panel')).slideDown().siblings().hide();
        var panel_name = $($(this).attr('href')).attr('id');
        ga('send', 'event', 'periodic table', 'panel view', panel_name, 1);
    });
    $('#home-update a').click(function () {
        ga('send', 'event', 'periodic table', 'offer click', '', 1);
    });
    $('#element-website').click(function () {
        ga('send', 'event', 'periodic table', 'element view website', $('#element-title span').text(), 1);
    });
    $('#element-wikipedia').click(function () {
        ga('send', 'event', 'periodic table', 'element view wikipedia', $('#element-title span').text(), 1);
    });
    $('#element-plugins').click(function () {
        ga('send', 'event', 'periodic table', 'element view plugin', $('#element-title span').text(), 1);
    });
    $('#element-category').click(function () {
        ga('send', 'event', 'periodic table', 'element view category list', $('#element-title span').text(), 1);
    });
    $('#element-model').click(function () {
        ga('send', 'event', 'periodic table', 'element view model list', $('#element-title span').text(), 1);
    });
    $('#element-close').click(function () {
        $('#element').fadeOut();
        $('#periodic-table').fadeIn();
        $('.main').fadeIn();
        ga('send', 'event', 'periodic table', 'element close', $('#element-title span').text(), 1);
    });
});