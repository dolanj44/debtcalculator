﻿$(document).ready(function () {

    /*/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    * 
    * Date methods to get rid of previous events
    * 
    *//////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*
    //gets current date
    var rightNow = new Date();
    //formats it according to the form we need i.e. YYYYMMDD
    var todayDate = rightNow.toISOString().slice(0, 10).replace(/-/g, "");
    //console.log(todayDate);

        //loops throught the event list and checks if event date is later than current date
        //if yes then turns display property of that event to none
    $(".event").each(function (index) {
        //console.log(index + ": " + $(this).data('date'));
        var eventDate = $(this).data('date');
        if (( eventDate - todayDate) < 0) {
            //console.log('hide the event');
            $(this).parent().parent().parent().parent().css({ "display": "none" });
        }
    });

    */
    
    /*/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    * 
    * IM status on teams page for browsers other than IE (activeX)
    * 
    *//////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Internet Explorer 6-11
    var isIE = /*@cc_on!@*/false || !!document.documentMode;
    // Edge 20+
    var isEdge = !isIE && !!window.StyleMedia;

    if (isIE == true || isEdge == true) {
        //$(".em-c-status").css('display','block');
        console.log("user opened IE/edge");
    }
    else {
        $(".ev-c-status").hide();
        //$(".ev-c-status").css('display', 'none');
        console.log("User opened browser other than IE");

    }

    /*/////////////////////////////////////////////////////////////////////////////////////////////////////////////
   * 
   * Active class for nav
   * 
   *//////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //$('#homeLink').addClass('em-is-current');
    /*
    $('.em-c-primary-nav__link').click(function () {
        $selectedElement = $(this);
        //console.log($selectedElement);

        //cycles through the li items
        $(".em-c-primary-nav__link").each(function (index) {
            //checks if each class has 'em-is-current', if not then it adds the class and removes it from the clicked
            //element to display it
            if ($(this).hasClass('em-is-current')) {
                $(this).removeClass('em-is-current');
            }
                $selectedElement.addClass('em-is-current');
            
        });
    });
    */

    /*/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    * 
    * Accordian open and close
    * 
    *//////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $('.em-is-closed').click(function () {
        $selectedElement = $(this);
        console.log($selectedElement);
  
        //cycles through the li items
        $(".em-c-accordion__item").each(function (index) {
            //checks if each class has 'em-is-closed', if not then it adds the class and removes it from the clicked
            //element to display it
            if (!$(this).hasClass('em-is-closed')) {
                $(this).addClass('em-is-closed');
                $selectedElement.removeClass('em-is-closed');
            }
        });
    });




    /*/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    * 
    * Add top-spacer class to teams page
    * 
    *//////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $('.team-link').click(function () {
        //$('#coaches').addClass('top-space').delay(1000);
        sessionStorage.setItem("teamClicked", "1");
        //alert('in onclick func');
    });

    /*/////////////////////////////////////////////////////////////////////////////////////////////////////////////
   * 
   * open and shut bright spot dropdownish strucure
   * 
   *//////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function clearSelected(id) {
        var active = $("#" + id);
        if (active.hasClass("list-article")) {
            active.toggleClass("selected");
            active.find(".list-article-body").slideToggle();
        }

        $(".list-article").not(active).removeClass("selected");
        $(".list-article").not(active).find(".list-article-body").slideUp();
    }
    $('#divArticleList').on('click', '.list-article', function (e) {
        console.log("inside function 1");
        clearSelected(this.id);
        e.stopPropagation();
    });




//document ready ends here
});






