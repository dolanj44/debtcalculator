/**
* @desc Collection of SharePoint REST API functions
* @example documented in each function
* Developed by: Luiz L Barreto
*/

(function() {
  'use strict';


  angular
  .module('myApp.services')
  .constant('SPRESTPATH', '_vti_bin/ListData.svc/')
  .constant('BASE_URL', 'https://path_to_your_sharepoint_site')
  .config(appConfig)
  .factory('SharePointService', dataService);

  appConfig.$inject = ['$httpProvider'];

  function appConfig($httpProvider) {
    $httpProvider.defaults.cache = true;
    $httpProvider.defaults.headers.common['Accept'] = 'application/json; odata=verbose';
    $httpProvider.defaults.headers.common['Content-Type'] = 'application/json; odata=verbose';
    $httpProvider.defaults.headers.post['Accept'] = 'application/json; odata=verbose';
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/json; odata=verbose';
  };

  dataService.$inject = ['$http', 'SPRESTPATH', 'BASE_URL', '$log'];

  function dataService($http, SPRESTPATH, BASE_URL, $log) {

    var data = {
      'userGet': userGet,
      'userGetId': userGetId,
      'currentUserId': 0,
      'userGetDetailsAndId': userGetDetailsAndId,
      'groupGetMembers': groupGetMembers,
      'groupGetMemberById': groupGetMemberById,
      'groupAddUserByLogin': groupAddUserByLogin,
      'listGetId': listGetId,
      'userSearch': userSearch,
      'email': email,
      'delete': del,
      'get': get,
      'getWithFilter': getWithFilter,
      'post': post,
      'update': update,
      'fileUpload': fileUpload,
      'uniqueTags': uniqueTags
    };



    /**
    * @desc 	Obtains information from user profile
    * @example 	SharePointService.userGet().then(function(response) {  });
    */
    function userGet() {
      var requestUrl = BASE_URL + "_api/sp.userprofiles.peoplemanager/getmyproperties";
      return $http({
        'method': 'GET',
        'url': requestUrl
      }).then(function(response){
        // console.log("User data retrieved");
        return response.data.d;
      }).catch(dataServiceError);
    }

    /**
    * @desc 	Obtains User Id to be used in merge/post requests
    * @example 	SharePointService.userGetId('upstreamaccts\\llbarr1').then(function(response) {  });
    */
    function userGetId(userName) {
      var prefix = "i:0#.w|";
      var accountName = prefix + userName;
      var requestUrl = BASE_URL + "_api/web/siteusers(@v)?@v='" +
      encodeURIComponent(accountName) + "'";
      return $http({
        'method': 'GET',
        'url': requestUrl
      }).then(function(response){
        // console.log("User Id retrieved");
        return response.data.d;
      }).catch(dataServiceError);
    }

    /**
    * @desc 	Obtains User details and user Id to be used in merge/post requests
    * @example 	SharePointService.userGetDetailsAndId().then(function(response) {  });
    */
    function userGetDetailsAndId() {

      var userData, userId;

      return userGet().then(function (response) {

        userData = response;

        return userGetId(userData.AccountName).then(function (response) {
          userId = response;
          return { 'userData': userData , 'userId': userId };

        });
      });
    }

    /**
    * @desc 	Peforms search against Client People Picker in SP2013
    * @example 	$scope.searchSP = function(user) {
    return SharePointService.searchUsers(user).then(function(response) {
    return JSON.parse(response.ClientPeoplePickerSearchUser);
  });
};
*/
function userSearch(term) {

  return getFormDigest().then(function (response) {

    var requestUrl = BASE_URL + "_api/SP.UI.ApplicationPages.ClientPeoplePickerWebServiceInterface.clientPeoplePickerSearchUser";
    var data = JSON.stringify({
      'queryParams':{
        '__metadata':{
          'type':'SP.UI.ApplicationPages.ClientPeoplePickerQueryParameters'
        },
        'AllowEmailAddresses':true,
        'AllowMultipleEntities':false,
        'AllUrlZones':false,
        'MaximumEntitySuggestions':50,
        'PrincipalSource':15,
        'PrincipalType': 1,
        'QueryString': term
      }
    });

    return $http({
      'method': 'POST',
      'data': data,
      'url': requestUrl,
      'headers': {
        "X-RequestDigest": response.data.d.GetContextWebInformation.FormDigestValue
      }
    }).then(function(response){
      console.log("User search performed");
      return response.data.d;
    }).catch(dataServiceError);

  });
}

/**
* @desc 	Obtains a list of members of a SharePoint Group
* @example 	SharePointService.groupGetMembers('Solutions Visitors').then(function(response) {  });
*/
function groupGetMembers(group) {
  var requestUrl = BASE_URL + "_api/web/sitegroups/getbyname('" + group + "')/users";
  return $http({
    'method': "GET",
    'url': requestUrl
  }).then(function(response){
    // console.log("Group members retrieved");
    return response.data.d.results;
  }).catch(dataServiceError);
};

/**
* @desc 	Verifies if a user Id belongs to a group
* @example 	SharePointService.groupGetMemberById('Solutions Owners', 1).then(function(response) {  });
*/
function groupGetMemberById(group, id) {
  var requestUrl = BASE_URL + "_api/web/sitegroups/getbyname('" + group + "')/users/getbyid(" + id + ")";
  return $http({
    'method': "GET",
    'url': requestUrl
  }).then(function(response){
    // console.log("Group membership retrieved");
    return response;
  }).catch(dataServiceError);
};

/**
* @desc 	Adds user login to a group
* @example 	SharePointService.groupAddUserById('Solutions Owners', user.LoginName).then(function(response) {  });
*/
function groupAddUserByLogin(group, login) {

  var requestUrl = BASE_URL + "_api/web/sitegroups/getbyname('" + group + "')/users";

  return getFormDigest().then(function (response) {

    return $http({
      'method': "POST",
      'url': requestUrl,
      'data': JSON.stringify({'__metadata': {'type': 'SP.User'},'LoginName': login}),
      'headers':
      {"X-RequestDigest": response.data.d.GetContextWebInformation.FormDigestValue }
    }).then(function(response){
      console.log("User added to group");
      return response;
    }).catch(dataServiceError);

  });
};

/**
* @desc 	Obtains list Id (e.g.: 2e2ed506-5be4-4e6b-976c-9b1576385678)
* @example 	SharePointService.listGetId('Users').then(function(response) {  });
*/
function listGetId(listname) {
  var requestUrl = BASE_URL + "_api/web/lists/getbytitle('" + listname + "')/Id";
  return $http({
    'method': 'GET',
    'url': requestUrl
  }).then(function(response){
    console.log("List Id retrieved");
    return response.data.d.Id;
  }).catch(dataServiceError);
}

/**
* @desc 	Emails a user using SP13 native email functionality. If from is left blank or an invalid email is provided, the tool will email as the Site title
* @example 	SharePointService.email(from, to, body, subject).then(function(response) {  });
*/
function email(from, to, body, subject) {

  return getFormDigest().then(function (response) {

    var requestUrl = BASE_URL + "_api/SP.Utilities.Utility.SendEmail";
    return $http({
      'method': 'POST',
      'url': requestUrl,
      'data': JSON.stringify({
        'properties': {
          '__metadata': {
            'type': 'SP.Utilities.EmailProperties'
          },
          'From': from,
          'To': {
            'results': to
          },
          'Body': body,
          'Subject': subject
        }
      }),
      'headers': { "X-RequestDigest": response.data.d.GetContextWebInformation.FormDigestValue }
    }).then(function(response){
      console.log("Email sent successfully");
    }).catch(dataServiceError);
  });
}

/**
* @desc 	Deletes an item from a list
* @example 	SharePointService.delete('Users',  user.Id, user.__metadata ).then(function(response) {  });
*/
function del(list, id, obj) {
  var requestUrl = BASE_URL + SPRESTPATH + list + "(" + id + ")";
  var accessType = "Microsoft.SharePoint.DataService." + list +"Item";
  obj.__metadata = { "type": accessType };
  return $http({
    'method': 'DELETE',
    'url': requestUrl,
    'data' : JSON.stringify(obj),
    'beforeSend' : function (request) {
      request.setRequestHeader("If-match", "*");
    }
  }).then(function(response){
    console.log("Delete Success");
    return data;
  }).catch(dataServiceError);
}

/**
* @desc 	Queries a list and loads all its fields
* @example 	SharePointService.get('Users').then(function(response) {  });
*/
function get(listname) {
  //var requestUrl = BASE_URL +  "_api/web/lists/getbytitle('" + listname + "')/items";
  var requestUrl = BASE_URL + SPRESTPATH + listname;
  return $http({
    'method': 'GET',
    'url': requestUrl,
    'cache': true
  }).then(function(response){
    return response.data.d.results;
  }).catch(dataServiceError);
}

/**
* @desc 	Queries a list with filter
* @example 	SharePointService.getWithFilter('Users', "?$expand=CreatedBy").then(function(response) {  });
*/
function getWithFilter(listname, filter) {
  //var requestUrl = BASE_URL +  "_api/web/lists/getbytitle('" + listname + "')/items" + filter;
  var requestUrl = BASE_URL + SPRESTPATH + listname + filter;
  return $http({
    'method': 'GET',
    'url': requestUrl,
    'cache': true
  }).then(function(response){
    return response.data.d.results;
  }).catch(dataServiceError);
}

/**
* @desc 	Posts to a list
* @example 	SharePointService.post('Users', obj).then(function(response) {  });
*/
function post(list, obj) {
  var requestUrl = BASE_URL + SPRESTPATH + list;
  return $http.post(requestUrl, obj)
  .then(function(data){
    return data;
  }).catch(dataServiceError);
}

/**
* @desc 	Updates a list item
* @example 	var obj = JSON.stringify( {'Title': 'New title' });
SharePointService.update(item.__metadata, obj).then(function(response) {  });
*/
function update(metadata, data) {
  return $http({
    'url': metadata.uri,
    'method': 'MERGE',
    'data': data,
    'headers':
    {"If-Match": "*"}
  }).then(function(data){
    console.log('List item updated');
    return data;
  }).catch(dataServiceError);
}

/**
* @desc 	Obtains unique elements using Underscore.js
* @example 	unique = SharePointService.uniqueTags(object, field);
*/
function uniqueTags(object, field) {
  return _.chain(object)
  .sortBy(field)
  .pluck(field)
  .flatten()
  .unique()
  .value();
}

/**
* @desc 	Uploads a file to a SharePoint folder. Relies on the fileRead directive to obtain file details
* @example 	var upload = SharePointService.upload('Documents', $scope.uploadme.src, $scope.filename);
*/
function fileUpload(serverRelativeUrlToFolder, arrayBuffer, fileName) {

  var xdigest;

  // Add the file to the SharePoint folder.
  addFileToFolder(arrayBuffer).then(function(response) {

    getListItem(response.d.ListItemAllFields.__deferred.uri).then(function(response) {

      updateListItem(response.__metadata).then(function(response) {

        console.log('File uploaded and updated');
      });
    });

  });

  // Add the file to the file collection in the Shared Documents folder.
  function addFileToFolder(arrayBuffer) {

    // Construct the endpoint
    var fileCollectionEndpoint = BASE_URL + "_api/web/getfolderbyserverrelativeurl('" + serverRelativeUrlToFolder + "')/files/add(overwrite=true, url='" + fileName + "')";

    return getFormDigest().then(function (response) {

      xdigest = response.data.d.GetContextWebInformation.FormDigestValue;

      // Send the request and return the response.
      // This call returns the SharePoint file.
      return jQuery.ajax({
        url: fileCollectionEndpoint,
        type: "POST",
        data: arrayBuffer,
        processData: false,
        headers: {
          "accept": "application/json;odata=verbose",
          "X-RequestDigest": xdigest,
          "content-length": arrayBuffer.byteLength
        },
        success: function(response) {
          return response.d;
        }
      });


    });
  }

  // Get the list item that corresponds to the file by calling the file's ListItemAllFields property.
  function getListItem(fileListItemUri) {

    // Send the request and return the response.
    return $http({
      'url': fileListItemUri,
      'method': "GET",
      'headers': { "accept": "application/json;odata=verbose" }
    }).then(function(response){
      return response.data.d;
    }).catch(dataServiceError);
  }

  // Change the display name and title of the list item.
  function updateListItem(itemMetadata) {

    // Define the list item changes. Use the FileLeafRef property to change the display name.
    // For simplicity, also use the name as the title.
    // The example gets the list item type from the item's metadata, but you can also get it from the
    // ListItemEntityTypeFullName property of the list.
    //var body = JSON.stringify("{{'__metadata':{{'type':'" + itemMetadata.type + "'}},'FileLeafRef':'" + fileName + "','Title':'" + fileName + "'}}";

    var body = JSON.stringify({
      '__metadata':{
        'type': itemMetadata.type },
        'FileLeafRef': fileName,
        'Title': fileName
      });

      // Send the request and return the promise.
      // This call does not return response content from the server.
      return $http({
        'url': itemMetadata.uri,
        'method': "POST",
        'data': body,
        'headers': {
          "X-RequestDigest": xdigest,
          "content-type": "application/json;odata=verbose",
          "content-length": body.length,
          "IF-MATCH": itemMetadata.etag,
          "X-HTTP-Method": "MERGE"
        }
      }).then(function(response){
        return response;
      }).catch(dataServiceError);
    }

  }

  return data;

  /**
  * @desc 	Used to obtain FormDigestValue used in POST operations
  * @example 	return getFormDigest().then(...
  */
  function getFormDigest() {
    var requestUrl = BASE_URL + "_api/contextinfo";
    return $http({
      'method': 'POST',
      'url': requestUrl
    });
  }

  /**
  * @desc 	Data service reporting function
  * @example 	....catch(dataServiceError);
  */
  function dataServiceError(errorResponse) {
    $log.error('XHR Failed for SharePointService');
    $log.error(errorResponse);
    return errorResponse;
  }
}

})();
