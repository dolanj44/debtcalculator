﻿$(document).ready(function () {


	/*/////////////////////////////////////////////////////////////////////////////////////////////////////////////
    * 
    * Landing zone type effect animation
    * 
    *//////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*
        * TheaterJS, a typing effect mimicking human behavior.
        *
        * Github repository: 
        * https://github.com/Zhouzi/TheaterJS
        *
        */

	var theater = theaterJS()


	theater
        .on('type:start, erase:start', function () {
        	theater.getCurrentActor().$element.classList.add('actor__content--typing')
        })
        .on('type:end, erase:end', function () {
        	theater.getCurrentActor().$element.classList.remove('actor__content--typing')
        })


	theater
        .addActor('rahul', {
        	speed: 1,
        	accuracy: 1
        })

        .addScene('rahul:Agile...', 200)
        .addScene('rahul:Lean...', 200)
        .addScene('rahul:DevOps...', 200)
        .addScene('rahul:Evolve', 500)
	//.addScene(theater.replay.bind(theater))

	//the sub title animation
	$('.tag-line').hide();
	setTimeout(function () {
		$('.tag-line').show().addClass('animated slideInLeft');
	}, 5400
	);
});